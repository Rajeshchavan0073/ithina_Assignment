//
//  EmployeeDetails+CoreDataClass.swift
//  ithena_assignment
//
//  Created by ashutosh deshpande on 13/05/2022.
//
//

import Foundation
import CoreData

@objc(EmployeeDetails)
public class EmployeeDetails: NSManagedObject {

}
