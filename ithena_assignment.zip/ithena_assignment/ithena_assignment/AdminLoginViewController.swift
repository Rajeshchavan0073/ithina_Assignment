//
//  AdminLoginViewController.swift
//  ithena_assignment
//
//  Created by ashutosh deshpande on 13/05/2022.
//

import UIKit
import Foundation

class AdminLoginViewController: UIViewController {
   
  
        
        var validation = Validation()
        
        let hrEmail = "sanjivani@ithena.ai"
        let hrPassword = "Sanjivani@22"
        
        @IBOutlet weak var emailTextInput: UITextField!
        @IBOutlet weak var passwordTextInput: UITextField!
        @IBOutlet weak var loginButton: UIButton!
        override func viewDidLoad() {
            super.viewDidLoad()
            self.hideKeyboardWhenTappedAround()
            // Do any additional setup after loading the view.
        }
        
        @IBAction func loginButton(_ sender: UIButton) {
            
            guard let email = emailTextInput.text, let password = passwordTextInput.text else {
                return
            }
            let isValidateEmail = self.validation.validateEmailId(emailID: email)
            if (isValidateEmail == false) {
                print("Incorrect Email")
                self.view.makeToast("Incorrect Email or Password", duration: 3.0, position: .top)
                return
            }
            
            let isValidatePass = self.validation.validatePassword(password: password)
            if (isValidatePass == false) {
                print("Incorrect Pass")
                self.view.makeToast("Incorrect Email or Password", duration: 3.0, position: .top)
                return
            }
            
            if (isValidateEmail == true || isValidatePass == true || hrEmail == email || hrPassword == password) {
                print("All fields are correct")
                let vc = storyboard?.instantiateViewController(withIdentifier: "AdminListViewController") as! AdminListViewController
                navigationController?.pushViewController(vc, animated: true)
                
            }
            
        }
        
    }



