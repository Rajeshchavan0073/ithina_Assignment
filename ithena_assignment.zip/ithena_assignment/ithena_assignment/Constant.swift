//
//  Constant.swift
//  ithena_assignment
//
//  Created by ashutosh deshpande on 13/05/2022.
//

import Foundation

class Constants {
    static let tech = ["Java","Swift","Php","Android","Angular","React"]
}
