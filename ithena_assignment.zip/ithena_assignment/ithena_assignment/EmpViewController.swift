//
//  EmpViewController.swift
//  ithena_assignment
//
//  Created by ashutosh deshpande on 13/05/2022.
//

import UIKit

class EmpViewController: UIViewController {

        var technology = ""
        var validation = Validation()
        
        @IBOutlet weak var firstNameText: UITextField!
        @IBOutlet weak var lastNameText: UITextField!
        @IBOutlet weak var emailText: UITextField!
        @IBOutlet weak var phoneNumberText: UITextField!
        @IBOutlet weak var technologyText: UITextField!
        @IBOutlet weak var pickerViewOutlet: UIPickerView!
        
        let context = (UIApplication.shared.delegate as! AppDelegate).persistentContainer.viewContext
        
        
        override func viewDidLoad() {
            super.viewDidLoad()
            self.hideKeyboardWhenTappedAround()
            
            // Do any additional setup after loading the view.
        }
        
        @IBAction func registerButton(_ sender: UIButton) {
            
            let newEmployeeDetails = EmployeeDetails(context: context)
            guard let email = emailText.text, let phone = phoneNumberText.text else {
                return
            }
            let isValidateEmail = self.validation.validateEmailId(emailID: email)
            if (isValidateEmail == false) {
                print("Incorrect Email")
                self.view.makeToast("Invalid Email", duration: 3.0, position: .top)
                return
            }
            let isValidatePhone = self.validation.validaPhoneNumber(phoneNumber: phone)
            if (isValidatePhone == false) {
                print("Incorrect Phone")
                self.view.makeToast("Invalid Phone Number", duration: 3.0, position: .top)
                return
            }
            
            if (isValidateEmail == true || isValidatePhone == true) {
                print("All fields are correct")
                newEmployeeDetails.phone = Int64(((phone as NSString).integerValue))
                newEmployeeDetails.technology = technology
            } else {
                print("Invalid Email or Phone Number")
                
            }
            newEmployeeDetails.firstName = firstNameText.text
            newEmployeeDetails.lastName = lastNameText.text
            newEmployeeDetails.emailID = emailText.text
            
            do {
                try context.save()
                self.view.makeToast("Registration Success", duration: 5.0, position: .top)
                
                
            } catch let error {
                print(error.localizedDescription)
            }
            let seconds = 3.0
            DispatchQueue.main.asyncAfter(deadline: .now() + seconds) {
            let vc = self.storyboard?.instantiateViewController(withIdentifier: "ViewController") as! ViewController; self.navigationController?.popToRootViewController(animated: true)
           }
            
        }
 }

    extension EmpViewController: UIPickerViewDelegate, UIPickerViewDataSource {
        func numberOfComponents(in pickerView: UIPickerView) -> Int {
            return 1
        }
        
        func pickerView(_ pickerView: UIPickerView, numberOfRowsInComponent component: Int) -> Int {
            return Constants.tech.count
        }
        
        func pickerView(_ pickerView: UIPickerView, titleForRow row: Int, forComponent component: Int) -> String? {
            return Constants.tech[row]
            
        }
        
        func pickerView(_ pickerView: UIPickerView, didSelectRow row: Int, inComponent component: Int) {
            hideKeyboardWhenTappedAround()
            technology = Constants.tech[row]
            technologyText.text = technology
            pickerView.isHidden = true
        }
    }


    extension EmpViewController: UITextFieldDelegate {
        func textFieldShouldBeginEditing(_ textField: UITextField) -> Bool {
            pickerViewOutlet.isHidden = false
            return false
        }
    }
    extension UIViewController {
        func hideKeyboardWhenTappedAround() {
            let tap = UITapGestureRecognizer(target: self, action: #selector(UIViewController.dismissKeyboard))
            tap.cancelsTouchesInView = false
            view.addGestureRecognizer(tap)
        }
        
        @objc func dismissKeyboard() {
            view.endEditing(true)
        }
    }
