//
//  AdminListViewController.swift
//  ithena_assignment
//
//  Created by ashutosh deshpande on 13/05/2022.
//

import UIKit

class AdminListViewController: UIViewController {
        
        @IBOutlet weak var hrListTableView: UITableView!
        
        let context = (UIApplication.shared.delegate as! AppDelegate).persistentContainer.viewContext
        
        override func viewDidLoad() {
            super.viewDidLoad()
            
            // Do any additional setup after loading the view.
        }
        
        func fetchTechnologyCountFromDB(techName: String) -> Int {
            let fetchRequest = EmployeeDetails.fetchRequest()
            fetchRequest.predicate = NSPredicate(format: "technology == %@", techName)
            do {
                let count = try context.count(for: fetchRequest)
                return count
            } catch let error {
                print(error.localizedDescription)
            }
            return 0
        }
    }


    extension AdminListViewController: UITableViewDelegate, UITableViewDataSource {
        func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
            return Constants.tech.count
        }
        
        func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
            let cell = tableView.dequeueReusableCell(withIdentifier: "cell")
            let technology = Constants.tech[indexPath.row]
            cell?.textLabel?.text = technology
            cell?.detailTextLabel?.text = "\(fetchTechnologyCountFromDB(techName: technology))"
            return cell!
        }
        func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
            let vc = storyboard?.instantiateViewController(withIdentifier: "DetailsViewController") as! DetailsViewController
                    vc.techName = Constants.tech[indexPath.row]
            navigationController?.pushViewController(vc, animated: true)
        }
        
        
    }
