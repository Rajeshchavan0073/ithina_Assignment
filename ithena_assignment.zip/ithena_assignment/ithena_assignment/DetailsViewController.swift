//
//  DetailsViewController.swift
//  ithena_assignment
//
//  Created by ashutosh deshpande on 13/05/2022.
//

import UIKit
import CoreData
class DetailsViewController: UIViewController {

    
        
        @IBOutlet weak var EmployeeInfoTableView: UITableView!
        
        
        var employees: [EmployeeDetails] = []
        
        var techName = ""
        
        let context = (UIApplication.shared.delegate as! AppDelegate).persistentContainer.viewContext
        
        
        override func viewDidLoad() {
            super.viewDidLoad()
            fetchEmployeeDetails()
        }
        
  
        func fetchEmployeeDetails() {
            let fetchRequest = EmployeeDetails.fetchRequest()
            fetchRequest.predicate = NSPredicate(format: "technology == %@", techName)
            do{
                employees = try context.fetch(fetchRequest)
                print(employees)
                EmployeeInfoTableView.reloadData()
            } catch let error {
                print(error.localizedDescription)
            }
            
        }
    }

    extension DetailsViewController: UITableViewDelegate, UITableViewDataSource {
        func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
            return employees.count
        }
        
        func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
            let cell1 = tableView.dequeueReusableCell(withIdentifier: "cell1") as! EmpDetailsTableViewCell
            let employee = self.employees[indexPath.row]
            cell1.firstNameTextLabel.text = employee.firstName
            cell1.lastNameTextLabel.text = employee.lastName
            cell1.emailTextLabel.text = employee.emailID
            cell1.phoneNumberTextLabel.text = "\(employee.phone)"
            return cell1
        }
        
        func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
            return 250.0
        }
    }

