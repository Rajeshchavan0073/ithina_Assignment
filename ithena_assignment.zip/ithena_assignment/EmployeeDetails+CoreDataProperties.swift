//
//  EmployeeDetails+CoreDataProperties.swift
//  ithena_assignment
//
//  Created by ashutosh deshpande on 13/05/2022.
//
//

import Foundation
import CoreData


extension EmployeeDetails {

    @nonobjc public class func fetchRequest() -> NSFetchRequest<EmployeeDetails> {
        return NSFetchRequest<EmployeeDetails>(entityName: "EmployeeDetails")
    }

    @NSManaged public var emailID: String?
    @NSManaged public var firstName: String?
    @NSManaged public var lastName: String?
    @NSManaged public var phone: Int64
    @NSManaged public var technology: String?

}

extension EmployeeDetails : Identifiable {

}
